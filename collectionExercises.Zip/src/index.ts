// Import from other modules here

function main() {
    // Call the functions for each exercise task here
    // fillUniqueArray();
    // intersectOfArrays();
}

main();
