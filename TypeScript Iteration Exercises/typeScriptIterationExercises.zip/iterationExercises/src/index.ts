import { printWithTabs } from "./exercises";

function main() {
    // Call the functions for each exercise task here
    // printWithTabs();
    // printWithCommas();
}

main();
